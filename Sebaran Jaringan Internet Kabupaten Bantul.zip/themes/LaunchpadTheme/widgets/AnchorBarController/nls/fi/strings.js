define({
  "_widgetLabel": "Ankkuririvin ohjain",
  "_layout_default": "Oletusasettelu",
  "_layout_layout1": "Asettelu 0",
  "more": "Lisää pienoisohjelmia"
});