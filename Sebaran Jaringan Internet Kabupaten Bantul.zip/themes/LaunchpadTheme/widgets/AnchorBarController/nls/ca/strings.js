define({
  "_widgetLabel": "Ancora el controlador de barra",
  "_layout_default": "Disseny per defecte",
  "_layout_layout1": "Disseny 0",
  "more": "Més widgets"
});