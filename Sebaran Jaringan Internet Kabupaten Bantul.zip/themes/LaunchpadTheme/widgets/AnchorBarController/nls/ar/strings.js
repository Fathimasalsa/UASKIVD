define({
  "_widgetLabel": "ارتساء مُتحكم الشريط",
  "_layout_default": "تخطيط افتراضي",
  "_layout_layout1": "تخطيط 0",
  "more": "مزيد من عناصر واجهة المستخدم"
});